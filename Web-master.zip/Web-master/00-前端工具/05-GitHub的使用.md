

## GitHub的使用


### GitHub添加wiki

参考链接：


- <https://juejin.im/post/5a3216c8f265da43333e6b54>

### GitHub项目添加 license

参考链接：

- <https://blog.csdn.net/qq_35246620/article/details/77647234>



### GitHub 引用图片的另一种方式

参考链接：

- [关于markdown文件插入图片遇到的小问题和解决办法](https://www.cnblogs.com/cxint/p/7200164.html)



