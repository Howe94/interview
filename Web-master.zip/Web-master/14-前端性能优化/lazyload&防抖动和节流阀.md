---
title: 07-自定义按键修饰符&自定义指令
publish: false
---

<ArticleTopAd></ArticleTopAd>





## lazyload

用的最多的场景是：

- 图片lazyload

- 组件lazyload

现在一般都单独做css的lazyload或者js的lazyload，因为这种方式，其实还是要加载图片和组件。



### 图片lazyload

图片一般是页面最大的资源，所以**非首屏**延迟加载很重要（让首屏尽快显示）。











## 防抖动（Debouncing）和节流阀（Throtting）




参考链接：

- [实例解析防抖动（Debouncing）和节流阀（Throttling）](http://www.css88.com/archives/7010)


